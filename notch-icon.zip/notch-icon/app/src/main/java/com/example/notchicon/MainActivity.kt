package com.example.notchicon

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            textSize = 16f
            text = "Когда ты делаешь скриншот, на месте выреза камеры на пару секунд " +
                "появляется иконка приложения, в котором он сделан.\n\n" +
                "1) Дай доступ к фото (чтобы увидеть новый скриншот).\n" +
                "2) Включи службу «Notch Icon» в спец. возможностях.\n\n" +
                "Если Android пишет, что настройка ограничена: Настройки → Приложения → " +
                "Notch Icon → ⋮ → «Разрешить ограниченные настройки»."
        })
        root.addView(Button(this).apply {
            text = "1. Доступ к фото"
            setOnClickListener {
                val perm = if (Build.VERSION.SDK_INT >= 33)
                    Manifest.permission.READ_MEDIA_IMAGES
                else Manifest.permission.READ_EXTERNAL_STORAGE
                requestPermissions(arrayOf(perm), 1)
            }
        }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(Button(this).apply {
            text = "2. Включить службу"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)
    }
}
